﻿namespace RomanNumeralCalculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnMultiply = new System.Windows.Forms.Button();
            this.BtnSubtract = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnDivide = new System.Windows.Forms.Button();
            this.LblAnswer = new System.Windows.Forms.Label();
            this.LblAns = new System.Windows.Forms.Label();
            this.TxtValue1 = new System.Windows.Forms.TextBox();
            this.TxtValue2 = new System.Windows.Forms.TextBox();
            this.BtnModulus = new System.Windows.Forms.Button();
            this.BtnAns = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnMultiply
            // 
            this.BtnMultiply.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMultiply.Location = new System.Drawing.Point(12, 179);
            this.BtnMultiply.Name = "BtnMultiply";
            this.BtnMultiply.Size = new System.Drawing.Size(96, 96);
            this.BtnMultiply.TabIndex = 7;
            this.BtnMultiply.Text = "*";
            this.BtnMultiply.UseVisualStyleBackColor = true;
            this.BtnMultiply.Click += new System.EventHandler(this.BtnMultiply_Click);
            // 
            // BtnSubtract
            // 
            this.BtnSubtract.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSubtract.Location = new System.Drawing.Point(114, 77);
            this.BtnSubtract.Name = "BtnSubtract";
            this.BtnSubtract.Size = new System.Drawing.Size(96, 96);
            this.BtnSubtract.TabIndex = 8;
            this.BtnSubtract.Text = "-";
            this.BtnSubtract.UseVisualStyleBackColor = true;
            this.BtnSubtract.Click += new System.EventHandler(this.BtnSubtract_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.Location = new System.Drawing.Point(12, 77);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(96, 96);
            this.BtnAdd.TabIndex = 9;
            this.BtnAdd.Text = "+";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnDivide
            // 
            this.BtnDivide.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDivide.Location = new System.Drawing.Point(114, 179);
            this.BtnDivide.Name = "BtnDivide";
            this.BtnDivide.Size = new System.Drawing.Size(96, 96);
            this.BtnDivide.TabIndex = 10;
            this.BtnDivide.Text = "/";
            this.BtnDivide.UseVisualStyleBackColor = true;
            this.BtnDivide.Click += new System.EventHandler(this.BtnDivide_Click);
            // 
            // LblAnswer
            // 
            this.LblAnswer.AutoSize = true;
            this.LblAnswer.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAnswer.Location = new System.Drawing.Point(67, 9);
            this.LblAnswer.Name = "LblAnswer";
            this.LblAnswer.Size = new System.Drawing.Size(0, 55);
            this.LblAnswer.TabIndex = 12;
            // 
            // LblAns
            // 
            this.LblAns.AutoSize = true;
            this.LblAns.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAns.Location = new System.Drawing.Point(325, 92);
            this.LblAns.Name = "LblAns";
            this.LblAns.Size = new System.Drawing.Size(166, 55);
            this.LblAns.TabIndex = 14;
            this.LblAns.Text = "Answer";
            // 
            // TxtValue1
            // 
            this.TxtValue1.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtValue1.Location = new System.Drawing.Point(196, 9);
            this.TxtValue1.Name = "TxtValue1";
            this.TxtValue1.Size = new System.Drawing.Size(178, 53);
            this.TxtValue1.TabIndex = 15;
            // 
            // TxtValue2
            // 
            this.TxtValue2.Font = new System.Drawing.Font("Times New Roman", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtValue2.Location = new System.Drawing.Point(12, 9);
            this.TxtValue2.Name = "TxtValue2";
            this.TxtValue2.Size = new System.Drawing.Size(178, 53);
            this.TxtValue2.TabIndex = 16;
            // 
            // BtnModulus
            // 
            this.BtnModulus.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnModulus.Location = new System.Drawing.Point(216, 179);
            this.BtnModulus.Name = "BtnModulus";
            this.BtnModulus.Size = new System.Drawing.Size(96, 96);
            this.BtnModulus.TabIndex = 17;
            this.BtnModulus.Text = "%";
            this.BtnModulus.UseVisualStyleBackColor = true;
            this.BtnModulus.Click += new System.EventHandler(this.BtnModulus_Click);
            // 
            // BtnAns
            // 
            this.BtnAns.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAns.Location = new System.Drawing.Point(216, 77);
            this.BtnAns.Name = "BtnAns";
            this.BtnAns.Size = new System.Drawing.Size(96, 96);
            this.BtnAns.TabIndex = 18;
            this.BtnAns.Text = "ANS";
            this.BtnAns.UseVisualStyleBackColor = true;
            this.BtnAns.Click += new System.EventHandler(this.BtnAns_Click);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 285);
            this.Controls.Add(this.BtnAns);
            this.Controls.Add(this.BtnModulus);
            this.Controls.Add(this.TxtValue2);
            this.Controls.Add(this.TxtValue1);
            this.Controls.Add(this.LblAns);
            this.Controls.Add(this.LblAnswer);
            this.Controls.Add(this.BtnDivide);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.BtnSubtract);
            this.Controls.Add(this.BtnMultiply);
            this.Name = "Calculator";
            this.Text = "Roman Numerals Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BtnMultiply;
        private System.Windows.Forms.Button BtnSubtract;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnDivide;
        private System.Windows.Forms.Label LblAnswer;
        private System.Windows.Forms.Label LblAns;
        private System.Windows.Forms.TextBox TxtValue1;
        private System.Windows.Forms.TextBox TxtValue2;
        private System.Windows.Forms.Button BtnModulus;
        private System.Windows.Forms.Button BtnAns;
    }
}

