﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RomanNumeralCalculator
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }
        public string Transaction(String roman)
        {
            return ArabicToRoman(RomanToArabic(roman));
        }
        public int RomanToArabic(String roman)
        {
            //Takes in the Roman Numeral and loops from the start to the end, translating each element and subtracting current from next
            int result = 0; //To be returned
            roman = roman.ToUpper(); //Eliminate Case Sensitivity
            for (int i = 0; i < roman.Length; i++)//Iterate through the string
            {            
                //Check to ensure that i isn't the final letter
                if(i < roman.Length-1 && Translate(roman[i]) < Translate(roman[i+1]))
                {   
                    result += Translate(roman[i + 1]) - Translate(roman[i]); //Add to result the difference between the current and next value
                    i++;
                    continue; //Pass back into the loop
                }
                else
                {
                    result += Translate(roman[i]); //Termination of the loop
                }
            }
            return result;
        }
        public static int Translate(char val)
        {
            //Parses Roman to Arabic based on the RomanNumerals Enum
            switch(val)
            {
                case 'I':
                    return 1;
                case 'V':
                    return 5;
                case 'X':
                    return 10;
                case 'L':
                    return 50;
                case 'C':
                    return 100;
                case 'D':
                    return 500;
                case 'M':
                    return 1000;

                default:
                    return 0;
            }
        }
        public String ArabicToRoman(int arabic)
        {
            MessageBox.Show(arabic.ToString());
            String res = "";
            List<Char> parts = new List<Char>();
            if(arabic <= 0)
            {
                return "NOTHING"; //Roman Numerals cannot be <= 0
            }
            while(arabic > 0)
            {
                //Thousands
                while(arabic >= 1000)
                {
                        parts.Add('M');
                        arabic -= 1000;
                }
          
                //Five Hundreds
                while(arabic >=500)
                {
                    if (arabic % 500 > 0)
                        parts.Add('D');
                        arabic -= 500;
                }
            
                //Hundreds
                while(arabic >= 100)
                {
                        parts.Add('C');
                        arabic -= 100;
                }
           
                //Fifties
                while (arabic >= 50)
                {
                        parts.Add('L');
                        arabic -= 50;
                }
           
                //Tens
                while (arabic >= 10)
                {
                        parts.Add('X');
                        arabic -= 10;
                }
          
                //Fives
                while (arabic >= 5)
                {
                        parts.Add('V');
                        arabic -= 5;
                }
              
                //Ones
                while (arabic >= 1)
                {
                        parts.Add('I');
                        arabic -= 1;
                }
            }
            foreach(char ch in parts)
            {
                res += ch;
            }
            res = res.Replace("IIII","IV");
            res = res.Replace("VIV", "IX");
            return res;
        }
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            LblAns.Text = ArabicToRoman(RomanToArabic(TxtValue1.Text) + RomanToArabic(TxtValue2.Text));
        }

        private void BtnSubtract_Click(object sender, EventArgs e)
        {
            LblAns.Text = ArabicToRoman(RomanToArabic(TxtValue1.Text) - RomanToArabic(TxtValue2.Text));
        }

        private void BtnMultiply_Click(object sender, EventArgs e)
        {
            LblAns.Text = ArabicToRoman(RomanToArabic(TxtValue1.Text) * RomanToArabic(TxtValue2.Text));
        }

        private void BtnDivide_Click(object sender, EventArgs e)
        {
            LblAns.Text = ArabicToRoman(RomanToArabic(TxtValue1.Text) / RomanToArabic(TxtValue2.Text));
        }

        private void BtnModulus_Click(object sender, EventArgs e)
        {
            LblAns.Text = ArabicToRoman(RomanToArabic(TxtValue1.Text) % RomanToArabic(TxtValue2.Text));
        }

        private void BtnAns_Click(object sender, EventArgs e)
        {
            if(isRoman(LblAns.Text))
            {
                TxtValue1.Text = LblAns.Text;
            }      
        }
        public Boolean isRoman(String text)
        {
            Char[] rms = { 'I', 'V', 'X', 'L', 'C', 'D', 'M' };
            foreach(char ch in text)
            {
                if(!rms.Contains(ch))
                    {
                    return false;
                }
            }
            return true;
        }
    }
    
}
